---
title: About Us
menus: about
weight: 10
description: About us
---

## A Community Service Organization

The Boyertown Rotary club has been proudly serving the Boyertown community since 1925. We are a non-religious, apolitical non-profit service organization. Our goal is to make the community, locally and globally, a little kinder, more peaceful place. We achieve this by supporting our neighbors and through person-to-person encounters. 


