+++
title = '{{ replace .File.ContentBaseName "-" " " | title }}'
+++
