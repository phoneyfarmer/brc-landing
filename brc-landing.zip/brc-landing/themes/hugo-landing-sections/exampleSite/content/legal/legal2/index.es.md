---
title: Legal 2
menus: legal
weigth: 20
description: Descripción Legal 2
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec urna massa,
vehicula facilisis nunc a, hendrerit feugiat ligula. Donec faucibus sit amet
massa eu eleifend. Vivamus porttitor massa a rutrum cursus. Pellentesque laoreet
felis eget lacus tempus, quis blandit nunc rutrum. Etiam sollicitudin congue
dolor, eu dignissim lacus feugiat id. Nam a felis urna. Nulla rhoncus quis justo
lacinia vehicula. Nunc in magna turpis. Phasellus quis augue enim. Donec aliquet
imperdiet ex vel semper.

Mauris sit amet ipsum elit. Curabitur condimentum vitae lacus a euismod. Quisque
ut nisi turpis. Nam nisl eros, gravida nec euismod sit amet, lacinia non justo.
Aenean mollis lacus mi, ut tempus sem sollicitudin eu. Interdum et malesuada
fames ac ante ipsum primis in faucibus. Donec non nulla suscipit, egestas odio
et, consequat lectus. Aliquam at pharetra eros. Integer risus arcu, iaculis quis
dui et, dapibus posuere eros. Vivamus sit amet justo rutrum, cursus dui quis,
ullamcorper lorem. Quisque tempor, erat ut viverra maximus, ipsum dui sagittis
diam, vitae pellentesque ipsum urna vitae purus.

Cras laoreet libero quis nibh bibendum congue. In maximus vehicula nunc quis
vestibulum. Proin tellus sem, interdum non luctus vulputate, vulputate sed eros.
Aliquam dui tortor, pretium a ligula sed, iaculis lacinia augue. Duis augue
nibh, viverra in sapien ac, porta volutpat purus. Curabitur blandit erat eu
nulla condimentum, a consectetur nisi rhoncus. Pellentesque efficitur posuere
nibh, id tincidunt lectus dictum ut. Sed lacinia maximus magna at efficitur.
Pellentesque eleifend, magna vitae pulvinar mattis, sapien justo auctor turpis,
in euismod orci dui a neque. Aenean condimentum magna et ligula elementum
imperdiet a auctor neque. Morbi suscipit ante et libero ornare, vitae auctor
nisi faucibus. Suspendisse sit amet semper risus. Aenean eu molestie dolor, a
tempus justo. Mauris volutpat enim nec porttitor auctor. Duis id sapien dui.
Nullam scelerisque egestas elementum.

Nullam turpis tellus, convallis at dictum quis, sagittis in tellus. Integer
consequat libero mauris, ac luctus nulla lobortis ac. Vestibulum dictum ex non
risus consectetur, vitae dapibus lectus vehicula. Vestibulum iaculis hendrerit
dui, sed ullamcorper lectus. Donec cursus quam eleifend magna vehicula egestas.
Maecenas sed mauris tellus. In ut arcu vitae massa dignissim eleifend.
Pellentesque id urna vel ante rhoncus laoreet nec non purus. Duis lobortis
volutpat vestibulum. Cras auctor efficitur malesuada. Praesent sed ligula in
orci fringilla venenatis sit amet nec sapien. Nulla at turpis ante. Sed leo
odio, malesuada eget fermentum nec, ornare in dolor. Praesent semper turpis
neque, sit amet interdum lectus commodo id. Ut pulvinar nibh eu aliquam
placerat. Quisque dui purus, dignissim quis ex et, tincidunt ullamcorper sem.

Sed accumsan, sapien eget ullamcorper scelerisque, nisi eros fringilla tortor,
finibus lacinia eros mauris eu arcu. Pellentesque quis hendrerit sapien. Donec
vulputate leo nisi, id feugiat libero placerat in. In sed diam vehicula,
venenatis erat non, malesuada arcu. Suspendisse sit amet laoreet mi, at molestie
nunc. Cras id leo facilisis, pellentesque nisi at, rhoncus sapien. Nulla
venenatis, arcu at auctor dictum, arcu felis efficitur felis, sagittis dapibus
metus tortor a sapien.

Ut placerat viverra augue, et mattis metus commodo vel. Nam at eleifend neque.
Fusce a dolor est. Integer ultricies, libero nec mollis bibendum, neque neque
faucibus nibh, eu condimentum purus neque a mauris. Nullam leo est, hendrerit
quis quam eu, dapibus congue magna. Cras sed maximus nisl. Aliquam pulvinar
suscipit ipsum, ultricies auctor augue scelerisque non. Vivamus imperdiet
posuere elit ut mollis. Aenean ultrices augue sit amet justo dictum, ut aliquet
ex convallis. Curabitur vulputate, mi et sodales consectetur, dolor sem volutpat
odio, eget posuere diam tellus semper sem. Nullam sit amet leo et risus
malesuada tempus ac vitae nisi. Pellentesque rutrum purus interdum orci
malesuada, vitae imperdiet tortor euismod. Aenean luctus imperdiet mattis.

Vivamus sapien leo, viverra eu ante vitae, hendrerit suscipit lorem. Nunc in
tempus lorem, ac porttitor velit. Cras ac nunc ac arcu molestie volutpat non et
ipsum. Donec ut ultrices sapien. Mauris pharetra ligula orci, quis pulvinar mi
ullamcorper eu. Mauris non augue ornare, lobortis nisi et, vestibulum arcu. Sed
sit amet molestie sem. Pellentesque ac commodo felis. Sed porttitor libero
tellus, nec bibendum neque imperdiet vehicula. Donec mattis consequat sem at
rhoncus. Ut porta mi ut risus eleifend, vel luctus turpis maximus. In sagittis
placerat ligula, ut ultricies est euismod bibendum.

Donec non nisl a purus ullamcorper fringilla. Aenean maximus felis at quam
consectetur, a iaculis nulla efficitur. Vestibulum eget blandit magna. Quisque
urna massa, scelerisque a luctus et, hendrerit eget sem. Fusce laoreet venenatis
aliquam. Etiam semper aliquet purus, blandit tristique nibh mollis in. Phasellus
odio turpis, scelerisque sit amet consequat nec, feugiat ac tortor. Donec
euismod ullamcorper leo in fermentum. Mauris dapibus mauris justo, sit amet
dapibus diam varius vel. Vestibulum et fringilla diam, mattis sollicitudin eros.
Maecenas sed commodo ipsum. Donec nibh erat, volutpat in libero quis, accumsan
interdum neque.
