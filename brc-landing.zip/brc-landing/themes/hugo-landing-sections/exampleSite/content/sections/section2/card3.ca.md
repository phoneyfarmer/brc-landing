---
title: Targeta 3
icon: arrow-repeat
weight: 30
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque commodo
volutpat enim quis dapibus. Nullam tristique diam ut tellus maximus gravida.
Proin sed consectetur lacus.

- Fusce a dolor in diam dignissim scelerisque.
- Donec aliquet lectus ut molestie tincidunt.
- Aliquam nec elit posuere, luctus odio et, finibus lacus.
- Cras nec orci ac dui tristique maximus.
- Nam eu nunc id arcu aliquam sagittis sed sed ante.
