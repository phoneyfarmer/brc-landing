---
title: Secció 2
img: section2.jpg
slogan: Slogan Secció 2
menus: sections
weight: 20
description: Descripció Secció 2
---
Ut eget erat dolor. Aliquam eget rutrum purus. Integer porttitor sem nec erat
fermentum, eget varius sapien luctus. Fusce ut libero eros. Aenean nec sodales
lorem. Curabitur pellentesque, lorem ac accumsan efficitur, libero purus
ullamcorper sem, nec pharetra tortor elit non enim. Cras lobortis commodo diam,
ut commodo ipsum consectetur eu. Phasellus id quam posuere, tempor velit rutrum,
semper mauris. Fusce odio mi, varius a auctor vel, porta non mi. Duis suscipit
erat ac mi mattis, venenatis pharetra nulla vulputate. Vestibulum leo purus,
porta nec nunc quis, bibendum consequat massa.

Suspendisse nec tempus velit. Maecenas non dapibus nulla. Phasellus lacinia
gravida sagittis. Aenean eleifend odio sed cursus accumsan. Suspendisse faucibus
lacus quis nisl tincidunt, id cursus tortor dignissim. Proin faucibus justo at
posuere vehicula. Curabitur vel porttitor odio. Quisque vel quam ipsum. Mauris
sollicitudin massa ac libero auctor, eu elementum risus tempus. Nunc id mauris
imperdiet, dapibus metus dapibus, vulputate enim. Nullam id eleifend justo, sit
amet sodales libero. Fusce suscipit volutpat est vitae faucibus.

Sed fermentum ante eu eros fringilla, in dapibus lacus pharetra. Phasellus
pulvinar gravida tempor. Duis placerat neque convallis velit rhoncus congue.
Suspendisse tincidunt iaculis urna, sit amet placerat nibh tempus et. Aenean
tempus facilisis arcu, non egestas neque. Maecenas ac est vitae ipsum imperdiet
convallis. Vestibulum tincidunt id magna sed venenatis.
