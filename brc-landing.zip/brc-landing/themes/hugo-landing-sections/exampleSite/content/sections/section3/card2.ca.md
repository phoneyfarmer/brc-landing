---
title: Targeta 2
icon: card-checklist
weight: 20
---

Quisque laoreet aliquam felis et vestibulum. Quisque molestie sapien nec nunc
mollis, eu bibendum magna vulputate. Nulla velit dui, varius sit amet
ullamcorper nec, pretium non erat. Nam id lorem sit amet magna ultricies viverra
eu non ipsum. Praesent et eleifend sem. Donec sed diam laoreet, accumsan ipsum
ac, mattis nibh. Donec ipsum velit, luctus vel dui vel, bibendum laoreet tortor.
Duis dictum augue augue, id elementum dui placerat at. Phasellus neque tortor,
viverra non rhoncus id, feugiat sed mi. Suspendisse potenti. Mauris quis magna
in orci porta varius ut et felis. Nunc eget varius mauris, in pellentesque elit.
Proin elementum urna eu dolor eleifend, eleifend fringilla nibh tempus. Praesent
tristique lectus vel dolor fringilla sagittis. Proin placerat varius quam, eu
viverra lectus venenatis ac.
